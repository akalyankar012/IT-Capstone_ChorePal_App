//
//  chorepal_prototypeApp.swift
//  chorepal prototype
//
//  Created by rayyan khan on 3/10/25.
//

import SwiftUI

@main
struct chorepal_prototypeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
