//
//  chorepal_prototypeTests.swift
//  chorepal prototypeTests
//
//  Created by rayyan khan on 3/10/25.
//

import Testing
@testable import chorepal_prototype

struct chorepal_prototypeTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
